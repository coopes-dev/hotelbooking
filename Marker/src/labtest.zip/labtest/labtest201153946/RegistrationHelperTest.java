package labtest.labtest201153946;

import labtest.RegistrationHelper;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Dylan
 *
 */
public class RegistrationHelperTest {
	
	RegistrationHelper helper;
	private final String NORMAL_USERNAME = "user123foo"; // Username that is expected to be accepted
	private final String NORMAL_PASSWORD = "passWORD12#^foo"; // Password that is expected to be accepted

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		helper = new RegistrationHelper();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link labtest.RegistrationHelper#checkUsernamePassword(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testCheckUsernamePassword() {
		
		System.out.println("testCheckUsernamePassword() RUNNING...");
		
		assertTrue("Normal test data fails", helper.checkUsernamePassword(NORMAL_USERNAME, "passWORD12#^foo")); // Testing normal data
		assertTrue("Null username is accepted", !helper.checkUsernamePassword("", NORMAL_PASSWORD)); // Testing null username
		assertTrue("Null password is accepted", !helper.checkUsernamePassword(NORMAL_USERNAME, "")); // Testing null password
		assertTrue("Username too long is accepted", !helper.checkUsernamePassword("user123foobar45", NORMAL_PASSWORD)); // Testing username too long
		assertTrue("Username 14 chars long (edge case) is rejected", helper.checkUsernamePassword("user123foobar4", NORMAL_PASSWORD)); // Testing boundary data on username length
		assertTrue("Username 9 chars long (edge case) is rejected", helper.checkUsernamePassword("user123fo", NORMAL_PASSWORD)); // Testing boundary data on username length
		assertTrue("Username too short is accepted", !helper.checkUsernamePassword("user123f", NORMAL_PASSWORD)); // Testing username too short
		assertTrue("Password too short is accepted", !helper.checkUsernamePassword(NORMAL_USERNAME, "passWORD12#")); // Testing password too short
		assertTrue("Password 12 chars long (edge case) is rejected", helper.checkUsernamePassword(NORMAL_USERNAME, "passWORD12#^")); // Testing boundary data on password length
		assertTrue("Password with no lower case is accepted", !helper.checkUsernamePassword(NORMAL_USERNAME, "PASSWORD12#^FOO")); // Testing password with no lower case
		assertTrue("Password with no upper case is accepted", !helper.checkUsernamePassword(NORMAL_USERNAME, "password12#^foo")); // Testing password with no uppercase
		assertTrue("Password with only one lower case is rejected", helper.checkUsernamePassword(NORMAL_USERNAME, "pASSWORD12#^FOO")); // Testing boundary data with one lower case char
		assertTrue("Password with only one upper case is rejected", helper.checkUsernamePassword(NORMAL_USERNAME, "Password12#^foo")); // Testing boundary data with one upper case char
		assertTrue("Password with no digits is accepted", !helper.checkUsernamePassword(NORMAL_USERNAME, "passWORDab#^foo")); // Testing password with no digits
		assertTrue("Password with one digit is rejected", helper.checkUsernamePassword(NORMAL_USERNAME, "passWORD1b#^foo")); // Testing boundary data with one digit
		assertTrue("Password with no special characters is accepted", !helper.checkUsernamePassword(NORMAL_USERNAME, "passWORD12abfoo")); // Testing password with no special characters
		assertTrue("Password with one special character is rejected", helper.checkUsernamePassword(NORMAL_USERNAME, "passWORD12#bfoo")); // Testing boundary data with one special char
		assertTrue("Passwords with a very long length is rejected", helper.checkUsernamePassword(NORMAL_USERNAME, "thisisareallylongpassWORD12#^foo")); // Testing boundary data with long password
	}

}
