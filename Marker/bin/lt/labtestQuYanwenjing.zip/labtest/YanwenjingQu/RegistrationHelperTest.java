package labtest.YanwenjingQu;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import labtest.RegistrationHelper;



public class RegistrationHelperTest {
	/**
	 * Test fixture
	 */
	private RegistrationHelper helper=null;
	private String validUsername = "abcdefGhi";
	private String validPassword = "aBcdefghi3(123";
	@Before
	public void setUp() throws Exception {
		helper=new RegistrationHelper();
	}

	@After
	public void tearDown() throws Exception {
		helper=new RegistrationHelper();
	}

	@Test
	public void test() {
        assertTrue("checking correct credentials",helper.checkUsernamePassword("abcABCdef\"","ABCabc123456789012*"));
        
		assertFalse("checking bad credentials",helper.checkUsernamePassword(null,null));		
	}
	
	// test Valid Username and Password
	public void testValidUsernamePassword() {
		assertTrue("checking correct credentials",helper.checkUsernamePassword(validUsername,validPassword));
	}
	
	// check null password 
	@Test
	public void testPasswordNull() {
		assertFalse("check null password", helper.checkUsernamePassword(validUsername, null));
	}
	
	//check null username
	@Test
	public void testUserNameNull() {
		assertFalse("check null username", helper.checkUsernamePassword(null, validPassword));
	}
	
	// Check username is long enough
	@Test
	public void testUsernameLength() {
		assertFalse("Check username is too long", helper.checkUsernamePassword("111123123213dsafdsa", validPassword));
		assertFalse("Check username is too long", helper.checkUsernamePassword("12345678901234", validPassword));
		assertFalse("Check username is too short", helper.checkUsernamePassword("", validPassword));
		assertFalse("Check username is too short", helper.checkUsernamePassword("12", validPassword));
		assertFalse("Check username is too short", helper.checkUsernamePassword("1234567", validPassword));
	}
	// Check username's length
	@Test
	public void testPasswordLength() {
		assertFalse("Check username is too short", helper.checkUsernamePassword(validUsername, "012345678912"));
		assertFalse("Check username is too short", helper.checkUsernamePassword(validUsername, ""));
	}
	
	// Check username starts with an alphabetic character
	@Test
	public void testStartWithAlphabetic() {
		assertFalse("Check username starts with an alphabetic character", helper.checkUsernamePassword("1bcdefGhi", validPassword));
	}
	
	// Check a lower case char in the password
	@Test
	public void testAlowerCharInPassword() {
		assertFalse("Check a lower case char in the password", helper.checkUsernamePassword(validUsername, "ABCDEFGHI3(123"));
	}
	
	// Check a upper case char in the password
	@Test
	public void testAupperCharInPassword() {
		assertFalse("Check a upper case char in the password", helper.checkUsernamePassword(validUsername, "abcdefghi3(123"));
	}
	
	// Check a digit in the password
	@Test
	public void testADigitInPassword() {
		assertFalse("Check a digit in the password", helper.checkUsernamePassword(validUsername, "abcdefghi*(def"));
	}
	
	//  check a special char in the password *"(
	@Test
	public void testAspCharInPassword() {
		assertFalse("Check a special char in the password", helper.checkUsernamePassword(validUsername, "abcdefghikjdef"));
	}

}
